/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CONNECTION;
import com.mysql.jdbc.Driver;
import java.sql.DriverManager;
import java.sql.Connection; // perbaikan typo
import java.sql.DriverManager;
import java.sql.SQLException;
/**
 *
 * @author ASUS
 */
public class Conec {
     private static Connection mysqlconfig;
    
    public static Connection GetConnection()throws SQLException{
        try{
            String url = "jdbc:mysql://localhost:3306/bokkeping";
            String user = "root";
            String pass = "";
            DriverManager.registerDriver(new com.mysql.jdbc.Driver());
            mysqlconfig = DriverManager.getConnection(url,user,pass);
            System.out.println("Koneksie Done");
        }catch(Exception e){
            System.err.println("koneksi gagal"+ e.getMessage());
        }
    return mysqlconfig;
    }
    
}
