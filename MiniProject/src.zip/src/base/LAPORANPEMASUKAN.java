/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package base;
import javax.swing.JFrame;
import CONNECTION.Conec;
import java.awt.Color;
import java.awt.Font;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Calendar;
import java.sql.Date;
import java.text.SimpleDateFormat;
import javax.imageio.ImageIO;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumn;
import CONNECTION.Util;

public class LAPORANPEMASUKAN extends javax.swing.JFrame {

    /**
     * Creates new form LAPORANPEMASUKAN
     */
    public LAPORANPEMASUKAN() {
        initComponents();
        setExtendedState(JFrame.MAXIMIZED_HORIZ);
        setVisible(true);
        setResizable(false);
        tanggal();
        id_tf_jual();
        id_produk();
       
        tabelTransaksiJ();
    }
    public void tanggal(){
    long millis = System.currentTimeMillis();
        Date date = new java.sql.Date(millis);
        System.out.println(date);
        String tgl = date.toString();
        txt_tanggal.setText(tgl);
        
        Calendar c = java.util.Calendar.getInstance();
        int tanggal = c.get(Calendar.DAY_OF_MONTH),
            bulan = c.get(Calendar.MONTH),
            tahun = c.get(Calendar.YEAR);
        
        String txt = getNamaHari(c.get(Calendar.DAY_OF_WEEK)) + ", " +
                tanggal + " " + getNamaBulan(bulan) + " "  + tahun;
        
        this.lbl_tgl.setText(txt);
    }
    
    private Calendar kalender = Calendar.getInstance();
    
    public String getNamaHari(int dayOfWeek){
        switch(kalender.get(Calendar.DAY_OF_WEEK)){
            case Calendar.SUNDAY: return "Minggu";
            case Calendar.MONDAY: return "Senin";
            case Calendar.TUESDAY: return "Selasa";
            case Calendar.WEDNESDAY: return "Rabu";
            case Calendar.THURSDAY: return "Kamis";
            case Calendar.FRIDAY: return "Jumat";
            case Calendar.SATURDAY: return "Sabtu";
            default: return "null";
        }
    }
    
    public String getNamaBulan(int bulan){
        switch(bulan){
            case Calendar.JANUARY: return "Januari";
            case Calendar.FEBRUARY: return "Februari";
            case Calendar.MARCH: return "Maret";
            case Calendar.APRIL: return "April";
            case Calendar.MAY: return "Mei";
            case Calendar.JUNE: return "Juni";
            case Calendar.JULY: return "Juli";
            case Calendar.AUGUST: return "Agustus";
            case Calendar.SEPTEMBER: return "September";
            case Calendar.OCTOBER: return "Oktober";
            case Calendar.NOVEMBER: return "November";
            case Calendar.DECEMBER: return "Desember";
            default: return "null";
        }
    }
     private void showData(String idTransaksi){
        try{
            String query = "SELECT * FROM transaksi_jual WHERE id_tr_jual = '"+idTransaksi+"'";
           Connection conn = (Connection)CONNECTION.Conec.GetConnection();
            Statement stat = conn.createStatement();
            ResultSet r = stat.executeQuery(query);
            
            if(r.next()){
                this.txt_tfjual.setText(r.getString("id_tf_jual"));
                this.id_pengguna.setText(r.getString("id_pengguna"));
                this.txt_idproduk.setSelectedItem(r.getString("id_produk"));
                this.txt_namaproduk.setText(r.getString("nama_produk"));
                this.txt_jumlah.setText(r.getString("jumlah"));
                this.txt_total.setText(r.getString("total_harga"));
                this.txt_tanggal.setText(r.getString("tanggal_tf_jual"));
           }
        }catch(SQLException ex){
            ex.printStackTrace();
            System.out.println(ex.getMessage());
        } 
    }
      public void tabelTransaksiJ () {
        DefaultTableModel tbl = new DefaultTableModel();
        tbl.addColumn("id_tf_jual");
        tbl.addColumn("id_pengguna");
        tbl.addColumn("id_produk");
        tbl.addColumn("nama_produk");
        tbl.addColumn("jumlah");
        tbl.addColumn("total harga");
        tbl.addColumn("tanggal_tf_jual");
        tabel_tJual.setModel(tbl);
        try {
            Connection conn = (Connection) CONNECTION.Conec.GetConnection();
            Statement stat = conn.createStatement();
            ResultSet res = stat.executeQuery("select * from tf_jual");
            while (res.next()) {
                tbl.addRow(new Object[]{
                    res.getString("id_tr_jual"),
                    res.getString("id_pengguna"),
                    res.getString("id_produk"),
                    res.getString("nama_produk"),
                    res.getString("jumlah"),
                    Util.convertToRupiah(Integer.parseInt(res.getString("total_harga"))),
                    res.getString("tanggal_tf_jual")
                });
                tabel_tJual.setModel(tbl);
                HeaderColumn();
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "salah" + e);
        }
    }
    
    public void HeaderColumn() {
        DefaultTableCellRenderer rightRenderer = new DefaultTableCellRenderer();

        rightRenderer.setHorizontalAlignment(JLabel.RIGHT);
        tabel_tJual.getColumnModel().getColumn(4).setCellRenderer(rightRenderer);
        tabel_tJual.getColumnModel().getColumn(5).setCellRenderer(rightRenderer);
        tabel_tJual.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);

        ((DefaultTableCellRenderer) tabel_tJual.getTableHeader().getDefaultRenderer()).setHorizontalAlignment(JLabel.CENTER);

        JTableHeader thead = tabel_tJual.getTableHeader();
        thead.setForeground(Color.BLACK);
        thead.setFont(new Font("Verdana", Font.BOLD, 12));

        TableColumn column;
        tabel_tJual.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        column = tabel_tJual.getColumnModel().getColumn(0);
        column.setPreferredWidth(100);
        tabel_tJual.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        column = tabel_tJual.getColumnModel().getColumn(1);
        column.setPreferredWidth(75);
        tabel_tJual.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        column = tabel_tJual.getColumnModel().getColumn(2);
        column.setPreferredWidth(75);
        tabel_tJual.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        column = tabel_tJual.getColumnModel().getColumn(3);
        column.setPreferredWidth(161);
        tabel_tJual.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        column = tabel_tJual.getColumnModel().getColumn(4);
        column.setPreferredWidth(56);
        tabel_tJual.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        column = tabel_tJual.getColumnModel().getColumn(5);
        column.setPreferredWidth(103);
        tabel_tJual.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        column = tabel_tJual.getColumnModel().getColumn(6);
        column.setPreferredWidth(95);
    }
     public void id_tf_jual() {
        try {
            String sql = "SELECT id_tf_jual FROM tf_jual order by id_tf_jual desc";
            Connection conn = (Connection) CONNECTION.Conec.GetConnection();
            java.sql.Statement stm = conn.createStatement();
            java.sql.ResultSet rs = stm.executeQuery(sql);

            if (rs.next()) {
                String idTJ = rs.getString("id_tf_jual").substring(3);
                String AN = "" + (Integer.parseInt(idTJ) + 1);
                String Nol = "";
                if (AN.length() == 1) {
                    Nol = "00";
                } else if (AN.length() == 2) {
                    Nol = "0";
                } else if (AN.length() == 3) {
                    Nol = "";

                }

                txt_tfjual.setText("TRJ" + Nol + AN);
            } else {
                txt_tfjual.setText("TRJ001");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "ERROR " + e.getMessage());
        }
    }
     public void id_produk(){
        try
        {
            String sql = "SELECT id_produk FROM produk order by id_produk desc";
            txt_idproduk.addItem("Pilih id_produk");
            Connection conn = (Connection) CONNECTION.Conec.GetConnection();
            java.sql.Statement stm = conn.createStatement();
            java.sql.ResultSet rs = stm.executeQuery(sql);
            while(rs.next())
            {
                txt_idproduk.addItem(rs.getString("id_produk"));
            }
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, "ERROR " + e.getMessage());
        }
    }
    
    private boolean cekStok(String idProd, int jumlah) throws SQLException{
        if(jumlah == 0){
            JOptionPane.showMessageDialog(this, "Jumlah stok tidak boleh 0!");
            return false;
        }
        
      Connection conn = (Connection) CONNECTION.Conec.GetConnection();
        Statement stat = conn.createStatement();
        ResultSet res = stat.executeQuery("SELECT stok FROM produk WHERE id_produk = '"+idProd+"'");
        
        if(res.next()){
            int stok = res.getInt("stok");
            if(jumlah > stok){
                JOptionPane.showMessageDialog(this, "Jumlah stok yang diinputkan melebihi " + stok);
                return false;
            }
        }
        return true;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        logot = new javax.swing.JButton();
        hapus = new javax.swing.JButton();
        Clean = new javax.swing.JButton();
        simpan = new javax.swing.JButton();
        kembali = new javax.swing.JButton();
        txt_tfjual = new javax.swing.JTextField();
        id_pengguna = new javax.swing.JTextField();
        txt_namaproduk = new javax.swing.JTextField();
        txt_jumlah = new javax.swing.JTextField();
        txt_total = new javax.swing.JTextField();
        txt_tanggal = new javax.swing.JTextField();
        lbl_tgl = new javax.swing.JLabel();
        txt_idproduk = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabel_tJual = new javax.swing.JTable();
        clean = new javax.swing.JButton();
        lbl_stok = new javax.swing.JLabel();
        cari = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        logot.setBackground(new java.awt.Color(0,0,0,1)
        );
        logot.setBorder(null);
        logot.setContentAreaFilled(false);
        logot.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        logot.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logotActionPerformed(evt);
            }
        });
        getContentPane().add(logot, new org.netbeans.lib.awtextra.AbsoluteConstraints(13, 710, 110, 40));

        hapus.setBackground(new java.awt.Color(0,0,0,1)
        );
        hapus.setBorder(null);
        hapus.setContentAreaFilled(false);
        hapus.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        hapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hapusActionPerformed(evt);
            }
        });
        getContentPane().add(hapus, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 110, 190, 80));

        Clean.setBackground(new java.awt.Color(0,0,0,1)
        );
        Clean.setBorder(null);
        Clean.setContentAreaFilled(false);
        Clean.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Clean.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CleanActionPerformed(evt);
            }
        });
        getContentPane().add(Clean, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 370, 180, 70));

        simpan.setBorder(null);
        simpan.setContentAreaFilled(false);
        simpan.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        simpan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                simpanActionPerformed(evt);
            }
        });
        getContentPane().add(simpan, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 250, 190, 70));

        kembali.setBackground(new java.awt.Color(0,0,0,1));
        kembali.setBorder(null);
        kembali.setContentAreaFilled(false);
        kembali.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        kembali.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                kembaliActionPerformed(evt);
            }
        });
        getContentPane().add(kembali, new org.netbeans.lib.awtextra.AbsoluteConstraints(943, 8, 130, 50));

        txt_tfjual.setBackground(new java.awt.Color(0,0,0,1)
        );
        txt_tfjual.setBorder(null);
        getContentPane().add(txt_tfjual, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 180, 260, 30));

        id_pengguna.setBackground(new java.awt.Color(0,0,0,1)
        );
        id_pengguna.setBorder(null);
        getContentPane().add(id_pengguna, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 220, 260, 30));

        txt_namaproduk.setBackground(new java.awt.Color(0,0,0,1)
        );
        txt_namaproduk.setBorder(null);
        getContentPane().add(txt_namaproduk, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 300, 260, 30));

        txt_jumlah.setBackground(new java.awt.Color(0,0,0,1)
        );
        txt_jumlah.setBorder(null);
        txt_jumlah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_jumlahActionPerformed(evt);
            }
        });
        getContentPane().add(txt_jumlah, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 330, 140, 40));

        txt_total.setBackground(new java.awt.Color(0,0,0,1)
        );
        txt_total.setBorder(null);
        getContentPane().add(txt_total, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 378, 260, 30));

        txt_tanggal.setBackground(new java.awt.Color(0,0,0,1)
        );
        txt_tanggal.setBorder(null);
        getContentPane().add(txt_tanggal, new org.netbeans.lib.awtextra.AbsoluteConstraints(402, 408, 260, 40));

        lbl_tgl.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 14)); // NOI18N
        getContentPane().add(lbl_tgl, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 40, 210, 30));

        txt_idproduk.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_idprodukActionPerformed(evt);
            }
        });
        getContentPane().add(txt_idproduk, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 260, 260, 30));

        tabel_tJual.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "id_tf_jual", "id_pengguna", "id_produk", "nama_produk", "jumlah", "total_harga", "tanggal_tf_jual"
            }
        ));
        jScrollPane1.setViewportView(tabel_tJual);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 500, 920, 260));

        clean.setBackground(new java.awt.Color(0,0,0,1)
        );
        clean.setBorder(null);
        clean.setContentAreaFilled(false);
        clean.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        getContentPane().add(clean, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 370, 190, 80));
        getContentPane().add(lbl_stok, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 340, 40, 20));

        cari.setBackground(new java.awt.Color(0,0,0,1)
        );
        cari.setBorder(null);
        cari.setContentAreaFilled(false);
        cari.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        cari.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cariActionPerformed(evt);
            }
        });
        getContentPane().add(cari, new org.netbeans.lib.awtextra.AbsoluteConstraints(980, 460, 40, 40));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/TAMPILAN/LAPORAN PEMASUKANNEW.png"))); // NOI18N
        jLabel1.setText("jLabel1");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1090, -1));

        setSize(new java.awt.Dimension(1095, 802));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void logotActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logotActionPerformed
        // TODO add your handling code here:
        Login Login =new Login();
        Login.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_logotActionPerformed

    private void hapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hapusActionPerformed
        // TODO add your handling code here:
          int status;
        status = JOptionPane.showConfirmDialog(this, "Apakah anda yakin ingin menghapus data?", "Confirm", JOptionPane.YES_OPTION, JOptionPane.QUESTION_MESSAGE);
        switch(status){
            case JOptionPane.YES_OPTION : 
        try{
            String idTJ = this.txt_tfjual.getText(),
            sql = "DELETE FROM tf_jual WHERE id_tf_jual = '" + idTJ + "'";

           Connection conn = (Connection) CONNECTION.Conec.GetConnection();
            Statement stat = conn.createStatement();
            if(stat.executeUpdate(sql) > 0){
                JOptionPane.showMessageDialog(this, "Data berhasil dihapus!");
                this.tabelTransaksiJ();
            }else{
                JOptionPane.showMessageDialog(this, "Data gagal dihapus!");
            }
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(this, ex.getMessage());
        }
        this.txt_tfjual.setText("");
        this.txt_idproduk.setSelectedItem("");
        this.txt_namaproduk.setText("");
        this.txt_jumlah.setText("");
        this.lbl_stok.setText("");
        this.txt_jumlah.setText("");
        this.txt_tanggal.setText("");
        this.id_pengguna.setText("");
        this.tabelTransaksiJ();
        tanggal();
        id_tf_jual();
                break;
        }
        
    }//GEN-LAST:event_hapusActionPerformed

    private void kembaliActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_kembaliActionPerformed
        // TODO add your handling code here:
        REPORT REPORT =new REPORT();
        REPORT.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_kembaliActionPerformed

    private void simpanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_simpanActionPerformed
        // TODO add your handling code here:
        String id_tf_jual = this.txt_tfjual.getText(),
        id_pengguna = this.id_pengguna.getText(),
        id_produk = this.txt_idproduk.getSelectedItem().toString(),
        nama_produk = this.txt_namaproduk.getText(),
        jumlah = this.txt_jumlah.getText(),
        total_harga = this.txt_total.getText(),
        tanggal_tf_jual = this.txt_tanggal.getText();
        try {
            if(!this.cekStok(id_produk, Integer.parseInt(jumlah))){
                return;
            }
            String sql = "INSERT INTO transaksi_jual VALUES (?, ?, ?, ?, ?, ?, ?)";
             Connection conn = (Connection) CONNECTION.Conec.GetConnection();
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, id_tf_jual);
            pst.setString(2, id_pengguna);
            pst.setString(3, id_produk);
            pst.setString(4, nama_produk);
            pst.setString(5, jumlah);
            pst.setString(6, total_harga);
            pst.setString(7, tanggal_tf_jual);
            pst.executeUpdate();
            JOptionPane.showMessageDialog(this, "Data berhasil ditambahkan!");
            conn.close();
        }catch(SQLException ex){
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error : " + ex.getMessage());
        }
        this.txt_tfjual.setText("");
        this.txt_idproduk.setSelectedItem("");
        this.txt_namaproduk.setText("");
        this.txt_jumlah.setText("");
        this.lbl_stok.setText("");
        this.txt_total.setText("");
        this.txt_tanggal.setText("");
        this.tabelTransaksiJ();
        this.id_pengguna.setText(Daftar.getid_pengguna());
        tanggal();
        id_tf_jual();
    }//GEN-LAST:event_simpanActionPerformed

    private void CleanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CleanActionPerformed
        // TODO add your handling code here:
        this.txt_idproduk.setSelectedItem("");
        this.txt_namaproduk.setText("");
        this.txt_jumlah.setText("");
        this.txt_total.setText("");
        this.lbl_stok.setText("");
        tanggal();
        id_tf_jual();
        tabelTransaksiJ();
        this.id_pengguna.setText(Daftar.getid_pengguna());
    }//GEN-LAST:event_CleanActionPerformed

    private void cariActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cariActionPerformed
        // TODO add your handling code here:
        String tampilan = "yyyy-MM-dd";
        SimpleDateFormat fm = new SimpleDateFormat(tampilan);
        String tgl = String.valueOf(fm.format(txt_tanggal.getdate()));

        DefaultTableModel tbl = new DefaultTableModel();
        tbl.addColumn("id_tf_jual");
        tbl.addColumn("id_pengguna");
        tbl.addColumn("id_produk");
        tbl.addColumn("nama_produk");
        tbl.addColumn("jumlah");
        tbl.addColumn("total harga");
        tbl.addColumn("tanggal");
        tabel_tJual.setModel(tbl);
        try {
            Connection conn = (Connection) CONNECTION.Conec.GetConnection();
            Statement stat = conn.createStatement();
            ResultSet res = stat.executeQuery("select * from tf_jual WHERE tanggal_tf_jual = '"+ tgl +"'");
           
            while (res.next()) {
                tbl.addRow(new Object[]{
                    res.getString("id_tr_jual"),
                    res.getString("id_pengguna"),
                    res.getString("id_produk"),
                    res.getString("nama_produk"),
                    res.getString("jumlah"),
                    Util.convertToRupiah(Integer.parseInt(res.getString("total_harga"))),
                    res.getString("tanggal_tf_jual")
                });
                tabel_tJual.setModel(tbl);
                HeaderColumn();
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "salah" + e);
        }
    }//GEN-LAST:event_cariActionPerformed

    private void txt_jumlahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_jumlahActionPerformed
        // TODO add your handling code here:
         try {
            String total = "SELECT harga FROM produk where id_produk = '"+ txt_idproduk.getSelectedItem() +"'";
            Connection conn = (Connection) CONNECTION.Conec.GetConnection();
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(total);
            if (rs.next()) {
                int harga = Integer.parseInt(rs.getString("harga"));
                int jumlah = Integer.parseInt(txt_jumlah.getText());
                this.txt_total.setText(String.valueOf(harga * jumlah));
            }
        } 
        catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }//GEN-LAST:event_txt_jumlahActionPerformed

    private void txt_idprodukActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_idprodukActionPerformed
        // TODO add your handling code here:
        if (txt_idproduk.getSelectedItem().equals(" ")){
            txt_namaproduk.setText("");
        }else{
            try
            {
                String sql = "SELECT * FROM produk WHERE id_produk = '"+ txt_idproduk.getSelectedItem() +"'";
             Connection conn = (Connection) CONNECTION.Conec.GetConnection();
                java.sql.Statement stm = conn.createStatement();
                java.sql.ResultSet rs = stm.executeQuery(sql);
                while(rs.next())
                {
                    txt_namaproduk.setText(rs.getString("nama"));
                    lbl_stok.setText(rs.getString("stok"));
                }
            }
            catch(Exception e)
            {
                JOptionPane.showMessageDialog(null, "ERROR " + e.getMessage());
            }
        }
    }//GEN-LAST:event_txt_idprodukActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(LAPORANPEMASUKAN.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(LAPORANPEMASUKAN.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(LAPORANPEMASUKAN.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(LAPORANPEMASUKAN.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new LAPORANPEMASUKAN().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Clean;
    private javax.swing.JButton cari;
    private javax.swing.JButton clean;
    private javax.swing.JButton hapus;
    private javax.swing.JTextField id_pengguna;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton kembali;
    private javax.swing.JLabel lbl_stok;
    private javax.swing.JLabel lbl_tgl;
    private javax.swing.JButton logot;
    private javax.swing.JButton simpan;
    private javax.swing.JTable tabel_tJual;
    private javax.swing.JComboBox<String> txt_idproduk;
    private javax.swing.JTextField txt_jumlah;
    private javax.swing.JTextField txt_namaproduk;
    private javax.swing.JTextField txt_tanggal;
    private javax.swing.JTextField txt_tfjual;
    private javax.swing.JTextField txt_total;
    // End of variables declaration//GEN-END:variables
}
