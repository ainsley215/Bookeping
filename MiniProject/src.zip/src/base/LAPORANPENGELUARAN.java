/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package base;

import javax.swing.JFrame;


import CONNECTION.Conec;
import java.awt.Color;
import java.awt.Font;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.util.Calendar;
import java.sql.Date;
import java.text.SimpleDateFormat;
import javax.imageio.ImageIO;
import javax.swing.JLabel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumn;
import CONNECTION.Util;
public class LAPORANPENGELUARAN extends javax.swing.JFrame {

    /**
     * Creates new form LAPORANPEMASUKA
     */
    public LAPORANPENGELUARAN() {
        initComponents();
        setExtendedState(JFrame.MAXIMIZED_HORIZ);
        setVisible(true);
        setResizable(false);
        tanggal();
        id_tf_beli();
        id_supplier();
        HeaderColumn();
        tabelTransaksiB();
        tanggal();
       
        
    }
    public void tanggal(){
    long millis = System.currentTimeMillis();
        Date date = new java.sql.Date(millis);
        System.out.println(date);
        String tgl = date.toString();
        txt_tanggal.setText(tgl);
        
        Calendar c = java.util.Calendar.getInstance();
        int tanggal = c.get(Calendar.DAY_OF_MONTH),
            bulan = c.get(Calendar.MONTH),
            tahun = c.get(Calendar.YEAR);
        
        String txt = getNamaHari(c.get(Calendar.DAY_OF_WEEK)) + ", " +
                tanggal + " " + getNamaBulan(bulan) + " "  + tahun;
        
        this.lbl_tanggal.setText(txt);
    }
    
    private Calendar kalender = Calendar.getInstance();
    
    public String getNamaHari(int dayOfWeek){
        switch(kalender.get(Calendar.DAY_OF_WEEK)){
            case Calendar.SUNDAY: return "Minggu";
            case Calendar.MONDAY: return "Senin";
            case Calendar.TUESDAY: return "Selasa";
            case Calendar.WEDNESDAY: return "Rabu";
            case Calendar.THURSDAY: return "Kamis";
            case Calendar.FRIDAY: return "Jumat";
            case Calendar.SATURDAY: return "Sabtu";
            default: return "null";
        }
    }
    
    public String getNamaBulan(int bulan){
        switch(bulan){
            case Calendar.JANUARY: return "Januari";
            case Calendar.FEBRUARY: return "Februari";
            case Calendar.MARCH: return "Maret";
            case Calendar.APRIL: return "April";
            case Calendar.MAY: return "Mei";
            case Calendar.JUNE: return "Juni";
            case Calendar.JULY: return "Juli";
            case Calendar.AUGUST: return "Agustus";
            case Calendar.SEPTEMBER: return "September";
            case Calendar.OCTOBER: return "Oktober";
            case Calendar.NOVEMBER: return "November";
            case Calendar.DECEMBER: return "Desember";
            default: return "null";
        }
    }
    private void showData(String idTransaksi){
        try{
            String query = "SELECT * FROM tf_beli WHERE id_tf_beli = '"+idTransaksi+"'";
            Connection conn = (Connection)CONNECTION.Conec.GetConnection();
            Statement stat = conn.createStatement();
            ResultSet r = stat.executeQuery(query);
            
            if(r.next()){
                this.txt_idtfbeli.setText(r.getString("id_tf_beli"));
                this.txt_idpengguna.setText(r.getString("id_pengguna"));
                this.id_supplier.setSelectedItem(r.getString("id_supplier"));
                 this.txt_idproduk.setText(r.getString("id_produk"));
                this.txt_namaproduk.setText(r.getString("nama_produk"));
                this.txt_jumlah.setText(r.getString("jumlah"));
                this.txt_jumlah.setText(r.getString("total_harga"));
                this.txt_tanggal.setText(r.getString("tanggal_tf_beli"));
           }
            
        }catch(SQLException ex){
            ex.printStackTrace();
            System.out.println(ex.getMessage());
        } 
    }
    public void tabelTransaksiB () {
        DefaultTableModel tbl = new DefaultTableModel();
        tbl.addColumn("id_tf_beli");
        tbl.addColumn("id_pengguna");
        tbl.addColumn("id_supplier");
        tbl.addColumn("id_produk");
        tbl.addColumn("nama_produk");
        tbl.addColumn("jumlah");
        tbl.addColumn("total_harga");
        tbl.addColumn("tanggal");
        tbl_tfbeli.setModel(tbl);
        try {
            Connection conn = (Connection) CONNECTION.Conec.GetConnection();
            Statement stat = conn.createStatement();
            ResultSet res = stat.executeQuery("select * from tf_beli");
            while (res.next()) {
                tbl.addRow(new Object[]{
                    res.getString("id_tf_beli"),
                    res.getString("id_pengguna"),
                    res.getString("id_supplier"),
                    res.getString("id_produk"),
                    res.getString("nama_produk"),
                    res.getString("jumlah"),
                    Util.convertToRupiah(Integer.parseInt(res.getString("total_harga"))),
                    res.getString("tanggal_tf_beli")
                });
                tbl_tfbeli.setModel(tbl);
                HeaderColumn();
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "salah" + e);
        }
    }
    public void HeaderColumn() {
        DefaultTableCellRenderer rightRenderer = new DefaultTableCellRenderer();

        rightRenderer.setHorizontalAlignment(JLabel.RIGHT);
        tbl_tfbeli.getColumnModel().getColumn(8).setCellRenderer(rightRenderer);
        tbl_tfbeli.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);

        ((DefaultTableCellRenderer) tbl_tfbeli.getTableHeader().getDefaultRenderer()).setHorizontalAlignment(JLabel.CENTER);

        JTableHeader thead = tbl_tfbeli.getTableHeader();
        thead.setForeground(Color.BLACK);
        thead.setFont(new Font("Verdana", Font.BOLD, 12));

        TableColumn column;
        tbl_tfbeli.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        column = tbl_tfbeli.getColumnModel().getColumn(0);
        column.setPreferredWidth(85);
        tbl_tfbeli.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        column = tbl_tfbeli.getColumnModel().getColumn(1);
        column.setPreferredWidth(75);
       tbl_tfbeli.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        column = tbl_tfbeli.getColumnModel().getColumn(2);
        column.setPreferredWidth(75);
        tbl_tfbeli.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        column = tbl_tfbeli.getColumnModel().getColumn(3);
        column.setPreferredWidth(141);
        tbl_tfbeli.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        column = tbl_tfbeli.getColumnModel().getColumn(4);
        column.setPreferredWidth(82);
        tbl_tfbeli.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        column = tbl_tfbeli.getColumnModel().getColumn(5);
        column.setPreferredWidth(103);
        tbl_tfbeli.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        column = tbl_tfbeli.getColumnModel().getColumn(6);
        column.setPreferredWidth(100);
         tbl_tfbeli.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        column = tbl_tfbeli.getColumnModel().getColumn(7);
        column.setPreferredWidth(100);
    }
     public void id_tf_beli() {
        try {
            String sql = "SELECT id_tf_beli FROM tf_beli order by id_tf_beli desc";
            Connection conn = (Connection) CONNECTION.Conec.GetConnection();
            java.sql.Statement stm = conn.createStatement();
            java.sql.ResultSet rs = stm.executeQuery(sql);

            if (rs.next()) {
                String idTB = rs.getString("id_tf_beli").substring(3);
                String AN = "" + (Integer.parseInt(idTB) + 1);
                String Nol = "";
                if (AN.length() == 1) {
                    Nol = "00";
                } else if (AN.length() == 2) {
                    Nol = "0";
                } else if (AN.length() == 3) {
                    Nol = "";

                }

                txt_idtfbeli.setText("TRB" + Nol + AN);
            } else {
                txt_idtfbeli.setText("TRB001");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "ERROR " + e.getMessage());
        }
    }
      public void id_supplier(){
        try
        {
            String sql = "SELECT id_supplier FROM supplier order by id_supplier desc";
            id_supplier.addItem("Pilih ID Supplier");
            Connection conn = (Connection) CONNECTION.Conec.GetConnection();
            java.sql.Statement stm = conn.createStatement();
            java.sql.ResultSet rs = stm.executeQuery(sql);
            while(rs.next())
            {
                id_supplier.addItem(rs.getString("id_supplier"));
            }
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, "ERROR " + e.getMessage());
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        kembali = new javax.swing.JButton();
        logout = new javax.swing.JButton();
        lbl_tanggal = new javax.swing.JLabel();
        txt_idtfbeli = new javax.swing.JTextField();
        txt_idpengguna = new javax.swing.JTextField();
        txt_idproduk = new javax.swing.JTextField();
        id_supplier = new javax.swing.JComboBox<>();
        txt_namaproduk = new javax.swing.JTextField();
        txt_jumlah = new javax.swing.JTextField();
        txt_total = new javax.swing.JTextField();
        txt_tanggal = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_tfbeli = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        kembali.setBackground(new java.awt.Color(0,0,0,1)
        );
        kembali.setBorder(null);
        kembali.setContentAreaFilled(false);
        kembali.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        kembali.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                kembaliActionPerformed(evt);
            }
        });
        getContentPane().add(kembali, new org.netbeans.lib.awtextra.AbsoluteConstraints(943, 18, 110, 30));

        logout.setBackground(new java.awt.Color(0,0,0,1)
        );
        logout.setBorder(null);
        logout.setContentAreaFilled(false);
        logout.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        logout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logoutActionPerformed(evt);
            }
        });
        getContentPane().add(logout, new org.netbeans.lib.awtextra.AbsoluteConstraints(13, 708, 120, 30));

        lbl_tanggal.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 14)); // NOI18N
        getContentPane().add(lbl_tanggal, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 46, 220, 20));

        txt_idtfbeli.setBackground(new java.awt.Color(0,0,0,1)
        );
        txt_idtfbeli.setBorder(null);
        getContentPane().add(txt_idtfbeli, new org.netbeans.lib.awtextra.AbsoluteConstraints(402, 180, 260, 30));

        txt_idpengguna.setBorder(null);
        getContentPane().add(txt_idpengguna, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 220, 260, 30));

        txt_idproduk.setBackground(new  java.awt.Color(0,0,0,1)
        );
        txt_idproduk.setBorder(null);
        getContentPane().add(txt_idproduk, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 300, 260, 30));

        getContentPane().add(id_supplier, new org.netbeans.lib.awtextra.AbsoluteConstraints(396, 260, 260, 30));

        txt_namaproduk.setBackground(new java.awt.Color(0,0,0,1)
        );
        txt_namaproduk.setBorder(null);
        getContentPane().add(txt_namaproduk, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 340, 260, 30));

        txt_jumlah.setBackground(new java.awt.Color(0,0,0,1)
        );
        txt_jumlah.setBorder(null);
        txt_jumlah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_jumlahActionPerformed(evt);
            }
        });
        getContentPane().add(txt_jumlah, new org.netbeans.lib.awtextra.AbsoluteConstraints(402, 370, 260, 40));

        txt_total.setBackground(new java.awt.Color(0,0,0,1)
        );
        txt_total.setBorder(null);
        getContentPane().add(txt_total, new org.netbeans.lib.awtextra.AbsoluteConstraints(402, 410, 260, 40));

        txt_tanggal.setBackground(new java.awt.Color(0,0,0,1)
        );
        txt_tanggal.setBorder(null);
        getContentPane().add(txt_tanggal, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 448, 260, 40));

        tbl_tfbeli.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "id_tf_beli", "id_pengguna", "id_supplier", "id_produk", "nama_produk", "jumlah", "total", "tanggal_tf_beli"
            }
        ));
        jScrollPane1.setViewportView(tbl_tfbeli);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 520, 930, 170));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/TAMPILAN/LAPORAN PENGELUARANbaru.png"))); // NOI18N
        jLabel1.setText("jLabel1");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1080, -1));

        setSize(new java.awt.Dimension(1093, 799));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void kembaliActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_kembaliActionPerformed
        // TODO add your handling code here:
        REPORT REPORT= new REPORT();
        REPORT.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_kembaliActionPerformed

    private void logoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logoutActionPerformed
        // TODO add your handling code here:
        Login Login =new Login();
        Login.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_logoutActionPerformed

    private void txt_jumlahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_jumlahActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_jumlahActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(LAPORANPENGELUARAN.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(LAPORANPENGELUARAN.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(LAPORANPENGELUARAN.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(LAPORANPENGELUARAN.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new LAPORANPENGELUARAN().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> id_supplier;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton kembali;
    private javax.swing.JLabel lbl_tanggal;
    private javax.swing.JButton logout;
    private javax.swing.JTable tbl_tfbeli;
    private javax.swing.JTextField txt_idpengguna;
    private javax.swing.JTextField txt_idproduk;
    private javax.swing.JTextField txt_idtfbeli;
    private javax.swing.JTextField txt_jumlah;
    private javax.swing.JTextField txt_namaproduk;
    private javax.swing.JTextField txt_tanggal;
    private javax.swing.JTextField txt_total;
    // End of variables declaration//GEN-END:variables
}
