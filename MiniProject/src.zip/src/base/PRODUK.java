/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package base;

import java.awt.Color;
import java.awt.Font;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Calendar;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumn;
import CONNECTION.Util;




public class PRODUK extends javax.swing.JFrame {

    /**
     * Creates new form PRODUK
     */
    public PRODUK() {
      initComponents();
        id_produk();
        tabelProduk();
        tanggal();
    }
      public void tanggal(){
    long millis = System.currentTimeMillis();
        Date date = new java.sql.Date(millis);
        System.out.println(date);
        String tgl = date.toString();
        
        Calendar c = java.util.Calendar.getInstance();
        int tanggal = c.get(Calendar.DAY_OF_MONTH),
            bulan = c.get(Calendar.MONTH),
            tahun = c.get(Calendar.YEAR);
        
        String txt = getNamaHari(c.get(Calendar.DAY_OF_WEEK)) + ", " +
                tanggal + " " + getNamaBulan(bulan) + " "  + tahun;
        
        this.lbl_tanggal.setText(txt);
    }
     private Calendar kalender = Calendar.getInstance();
    
    public String getNamaHari(int dayOfWeek){
        switch(kalender.get(Calendar.DAY_OF_WEEK)){
            case Calendar.SUNDAY: return "Minggu";
            case Calendar.MONDAY: return "Senin";
            case Calendar.TUESDAY: return "Selasa";
            case Calendar.WEDNESDAY: return "Rabu";
            case Calendar.THURSDAY: return "Kamis";
            case Calendar.FRIDAY: return "Jumat";
            case Calendar.SATURDAY: return "Sabtu";
            default: return "null";
        }
    }
    public String getNamaBulan(int bulan){
        switch(bulan){
            case Calendar.JANUARY: return "Januari";
            case Calendar.FEBRUARY: return "Februari";
            case Calendar.MARCH: return "Maret";
            case Calendar.APRIL: return "April";
            case Calendar.MAY: return "Mei";
            case Calendar.JUNE: return "Juni";
            case Calendar.JULY: return "Juli";
            case Calendar.AUGUST: return "Agustus";
            case Calendar.SEPTEMBER: return "September";
            case Calendar.OCTOBER: return "Oktober";
            case Calendar.NOVEMBER: return "November";
            case Calendar.DECEMBER: return "Desember";
            default: return "null";
        }
    }
    public void tabelProduk () {
        DefaultTableModel tbl = new DefaultTableModel();
        tbl.addColumn("id_produk");
        tbl.addColumn("nama_produk");
        tbl.addColumn("stok_produk");
        tbl.addColumn("harga_jual");
        tbl.addColumn("harga_beli");
        tabel_produk.setModel(tbl);
        try {
             Connection conn = (Connection) CONNECTION.Conec.GetConnection();
            Statement stat = conn.createStatement();
            ResultSet res = stat.executeQuery("select * from produk");
            while (res.next()) {
                tbl.addRow(new Object[]{
                    res.getString("id_produk"),
                    res.getString("nama_produk"),
                    res.getString("stok_produk"),
                    Util.convertToRupiah(Integer.parseInt(res.getString("harga_jual"))),
                    Util.convertToRupiah(Integer.parseInt(res.getString("harga_beli"))),
                    
                });
                tabel_produk.setModel(tbl);
                HeaderColumn();
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "salah" + e);
        }
    }
    public void HeaderColumn() {
        DefaultTableCellRenderer rightRenderer = new DefaultTableCellRenderer();

        rightRenderer.setHorizontalAlignment(JLabel.RIGHT);
        tabel_produk.getColumnModel().getColumn(4).setCellRenderer(rightRenderer);
        tabel_produk.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);

        ((DefaultTableCellRenderer) tabel_produk.getTableHeader().getDefaultRenderer()).setHorizontalAlignment(JLabel.CENTER);

        JTableHeader thead = tabel_produk.getTableHeader();
        thead.setForeground(Color.BLACK);
        thead.setFont(new Font("Tahoma", Font.BOLD, 12));

        TableColumn column;
        tabel_produk.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        column = tabel_produk.getColumnModel().getColumn(0);
        column.setPreferredWidth(90);
        tabel_produk.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        column = tabel_produk.getColumnModel().getColumn(1);
        column.setPreferredWidth(100);
        tabel_produk.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        column = tabel_produk.getColumnModel().getColumn(2);
        column.setPreferredWidth(140);
        tabel_produk.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        column = tabel_produk.getColumnModel().getColumn(3);
        column.setPreferredWidth(115);
        tabel_produk.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        column = tabel_produk.getColumnModel().getColumn(4);
        column.setPreferredWidth(120);
       
    }
     private void showData(String idProduk){
        try{
            String query = "SELECT * FROM produk WHERE id_produk = '"+idProduk+"'";
            Connection conn = (Connection)CONNECTION.Conec.GetConnection();
            Statement stat = conn.createStatement();
            ResultSet r = stat.executeQuery(query);
            
            if(r.next()){
                this.id_produk.setText(r.getString("id_produk"));
                this.nama_produk.setText(r.getString("nama_produk"));
                this.stok_produk.setText(r.getString("stok_produk")); 
                this.harga_jual.setText(r.getString("harga_jual"));
                this.harga_beli.setText(r.getString("harga_beli"));
           }
            
        }catch(SQLException ex){
            ex.printStackTrace();
            System.out.println(ex.getMessage());
        } 
    }
     public void id_produk() {
        try {
            String sql = "SELECT id_produk FROM produk order by id_produk desc";
            Connection conn = (Connection) CONNECTION.Conec.GetConnection();
            Statement stm = conn.createStatement();
            ResultSet rs = stm.executeQuery(sql);

            if (rs.next()) {
                String idP = rs.getString("id_produk").substring(2);
                String AN = "" + (Integer.parseInt(idP) + 1);
                String Nol = "";
                if (AN.length() == 1) {
                    Nol = "0";
//                } else if (AN.length() == 2) {
//                    Nol = "0";
                } else if (AN.length() == 3) {
                    Nol = "";

                }

                id_produk.setText("PD" + Nol + AN);
            } else {
                id_produk.setText("PD01");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "ERROR " + e.getMessage());
        }
    }
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        DASBOARD = new javax.swing.JButton();
        SUPPLIER = new javax.swing.JButton();
        REPORT = new javax.swing.JButton();
        nama_produk = new javax.swing.JTextField();
        stok_produk = new javax.swing.JTextField();
        harga_jual = new javax.swing.JTextField();
        harga_beli = new javax.swing.JTextField();
        lbl_tanggal = new javax.swing.JLabel();
        tambah = new javax.swing.JButton();
        hapus = new javax.swing.JButton();
        edit = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabel_produk = new javax.swing.JTable();
        id_produk = new javax.swing.JTextField();
        FRAME = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        DASBOARD.setBackground(new java.awt.Color(0,0,0,1)
        );
        DASBOARD.setBorder(null);
        DASBOARD.setContentAreaFilled(false);
        DASBOARD.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        DASBOARD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DASBOARDActionPerformed(evt);
            }
        });
        getContentPane().add(DASBOARD, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 170, 130, 30));

        SUPPLIER.setBackground(new java.awt.Color(0,0,0,1)
        );
        SUPPLIER.setBorder(null);
        SUPPLIER.setContentAreaFilled(false);
        SUPPLIER.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        SUPPLIER.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SUPPLIERActionPerformed(evt);
            }
        });
        getContentPane().add(SUPPLIER, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 258, 130, 30));

        REPORT.setBackground(new java.awt.Color(0,0,0,1)
        );
        REPORT.setBorder(null);
        REPORT.setContentAreaFilled(false);
        REPORT.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        REPORT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                REPORTActionPerformed(evt);
            }
        });
        getContentPane().add(REPORT, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 310, 120, 30));

        nama_produk.setBackground(new java.awt.Color(0,0,0,1)
        );
        nama_produk.setBorder(null);
        getContentPane().add(nama_produk, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 570, 130, 40));

        stok_produk.setBackground(new java.awt.Color(0,0,0,1)
        );
        stok_produk.setBorder(null);
        stok_produk.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                stok_produkActionPerformed(evt);
            }
        });
        getContentPane().add(stok_produk, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 570, 130, 40));

        harga_jual.setBackground(new java.awt.Color(0,0,0,1)
        );
        harga_jual.setBorder(null);
        harga_jual.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                harga_jualActionPerformed(evt);
            }
        });
        getContentPane().add(harga_jual, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 570, 120, 40));

        harga_beli.setBackground(new java.awt.Color(0,0,0,1)
        );
        harga_beli.setBorder(null);
        harga_beli.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                harga_beliActionPerformed(evt);
            }
        });
        getContentPane().add(harga_beli, new org.netbeans.lib.awtextra.AbsoluteConstraints(930, 570, 130, 40));

        lbl_tanggal.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 14)); // NOI18N
        getContentPane().add(lbl_tanggal, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 40, 300, 30));

        tambah.setBackground(new java.awt.Color(0,0,0,1)
        );
        tambah.setBorder(null);
        tambah.setContentAreaFilled(false);
        tambah.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        tambah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tambahActionPerformed(evt);
            }
        });
        getContentPane().add(tambah, new org.netbeans.lib.awtextra.AbsoluteConstraints(533, 690, 160, 60));

        hapus.setBackground(new java.awt.Color(0,0,0,1)
        );
        hapus.setBorder(null);
        hapus.setContentAreaFilled(false);
        hapus.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        hapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hapusActionPerformed(evt);
            }
        });
        getContentPane().add(hapus, new org.netbeans.lib.awtextra.AbsoluteConstraints(703, 688, 170, 70));

        edit.setBackground(new java.awt.Color(0,0,0,1)
        );
        edit.setBorder(null);
        edit.setContentAreaFilled(false);
        edit.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        edit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editActionPerformed(evt);
            }
        });
        getContentPane().add(edit, new org.netbeans.lib.awtextra.AbsoluteConstraints(890, 688, 170, 70));

        tabel_produk.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "id_produk", "nama_produk", "stok_produk", "harga_jual", "harga_beli"
            }
        ));
        jScrollPane1.setViewportView(tabel_produk);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 110, 570, 220));

        id_produk.setBackground(new java.awt.Color(0,0,0,1)
        );
        id_produk.setBorder(null);
        getContentPane().add(id_produk, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 578, 120, 30));

        FRAME.setForeground(new java.awt.Color(0, 0, 0));
        FRAME.setIcon(new javax.swing.ImageIcon(getClass().getResource("/TAMPILAN/PRODUKnew_1.png"))); // NOI18N
        FRAME.setText("jLabel1");
        getContentPane().add(FRAME, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1080, -1));

        setSize(new java.awt.Dimension(1094, 798));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void REPORTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_REPORTActionPerformed
        // TODO add your handling code here:
        REPORT REPORT =new REPORT();
        REPORT.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_REPORTActionPerformed

    private void DASBOARDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DASBOARDActionPerformed
        // TODO add your handling code here:
        DASBOARD DASBOARD =new DASBOARD();
        DASBOARD.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_DASBOARDActionPerformed

    private void SUPPLIERActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SUPPLIERActionPerformed
        // TODO add your handling code here:
        SUPPLIER SUPPLIER =new SUPPLIER();
        SUPPLIER.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_SUPPLIERActionPerformed

    private void harga_beliActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_harga_beliActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_harga_beliActionPerformed

    private void tambahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tambahActionPerformed
        // TODO add your handling code here:
        String id_produk = this.id_produk.getText(),
        nama_produk = this.nama_produk.getText(),
        stok_produk = this.stok_produk.getText(),
        harga_jual = this.harga_jual.getText(),
        harga_beli = this.harga_beli.getText();
        
        try {
            String sql = "INSERT INTO produk VALUES (?, ?, ?, ?, ?)";
            Connection conn = (Connection) CONNECTION.Conec.GetConnection();
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, id_produk);
            pst.setString(2, nama_produk);
            pst.setString(3, stok_produk);
            pst.setString(4, harga_jual);
            pst.setString(5, harga_beli);
            
            // eksekusi query
            pst.executeUpdate();
            JOptionPane.showMessageDialog(this, "Data berhasil ditambahkan!");
            conn.close();
        }catch(SQLException ex){
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error : " + ex.getMessage());
        }
        this.id_produk.setText("");
        this.nama_produk.setText("");
        this.stok_produk.setText("");
        this.harga_jual.setText("");
        this.harga_beli.setText("");
        this.tabelProduk();
        id_produk();
         
    }//GEN-LAST:event_tambahActionPerformed

    private void editActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editActionPerformed
        // TODO add your handling code here:
         try {
            String id_produk = this.id_produk.getText(),
            nama_produk = this.nama_produk.getText(),
            stok_produk = this.stok_produk.getText(),
            harga_jual = this.harga_jual.getText(),
            harga_beli = this.harga_beli.getText(),
            
            sql = String.format("UPDATE produk SET  nama_produk = '%s', stok_produk= '%s', harga_jual= '%s', harga_beli = '%s' WHERE id_produk = '%s'", nama_produk, stok_produk, harga_jual, harga_beli, id_produk);

            System.out.println("id_produk : " + id_produk);

             Connection conn = (Connection) CONNECTION.Conec.GetConnection();
            Statement stat = conn.createStatement();
            stat.executeUpdate(sql);
            JOptionPane.showMessageDialog(this, "Data berhasil diupdate!");
            this.showData(id_produk);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage());
        }
        this.id_produk.setText("");
        this.nama_produk.setText("");
        this.stok_produk.setText("");
        this.harga_jual.setText("");
        this.harga_beli.setText("");
        this.tabelProduk();
        id_produk();
    }//GEN-LAST:event_editActionPerformed

    private void stok_produkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_stok_produkActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_stok_produkActionPerformed

    private void harga_jualActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_harga_jualActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_harga_jualActionPerformed

    private void hapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hapusActionPerformed
        // TODO add your handling code here:
          int status;
        status = JOptionPane.showConfirmDialog(this, "Apakah anda yakin ingin menghapus data?", "Confirm", JOptionPane.YES_OPTION, JOptionPane.QUESTION_MESSAGE);
        switch(status){
            case JOptionPane.YES_OPTION : 
            try{
            String idP = this.id_produk.getText(),
            sql = "DELETE FROM produk WHERE id_produk = '" + idP + "'";

             Connection conn = (Connection) CONNECTION.Conec.GetConnection();
            Statement stat = conn.createStatement();
            // mengecek apakah data pembeli berhasil terhapus atau tidak
            if(stat.executeUpdate(sql) > 0){
                JOptionPane.showMessageDialog(this, "Data berhasil dihapus!");
                // mengupdate tabel
                //                this.showData(idK);
                this.tabelProduk();
            }else{
                JOptionPane.showMessageDialog(this, "Data gagal dihapus!");
            }
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(this, ex.getMessage());
        }
        this.id_produk.setText("");
        this.nama_produk.setText("");
        this.stok_produk.setText("");
        this.harga_jual.setText("");
        this.harga_beli.setText("");
        this.tabelProduk();
        id_produk();
                break;
        }
    }//GEN-LAST:event_hapusActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PRODUK.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PRODUK.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PRODUK.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PRODUK.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PRODUK().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton DASBOARD;
    private javax.swing.JLabel FRAME;
    private javax.swing.JButton REPORT;
    private javax.swing.JButton SUPPLIER;
    private javax.swing.JButton edit;
    private javax.swing.JButton hapus;
    private javax.swing.JTextField harga_beli;
    private javax.swing.JTextField harga_jual;
    private javax.swing.JTextField id_produk;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lbl_tanggal;
    private javax.swing.JTextField nama_produk;
    private javax.swing.JTextField stok_produk;
    private javax.swing.JTable tabel_produk;
    private javax.swing.JButton tambah;
    // End of variables declaration//GEN-END:variables
}
