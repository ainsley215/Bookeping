/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package base;

import javax.swing.JFrame;
import CONNECTION.Conec;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Calendar;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import javax.swing.table.JTableHeader;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.io.InputStream;
import javax.imageio.ImageIO;
import javax.swing.JLabel;

/**
 *
 * @author ASUS
 */
public class SUPPLIER extends javax.swing.JFrame {

    /**
     * Creates new form SUPPLIER
     */
    public SUPPLIER() {
        initComponents();
        setExtendedState(JFrame.MAXIMIZED_HORIZ);
        setVisible(true);
        setResizable(false);
        id_supplier();
        tabelSupplier();
        tanggal();
    }
     public void tanggal(){
    long millis = System.currentTimeMillis();
        java.sql.Date date = new java.sql.Date(millis);
        System.out.println(date);
        String tgl = date.toString();
//        txt_tgl.setText(tgl);
        
        java.util.Calendar c = java.util.Calendar.getInstance();
        int tanggal = c.get(Calendar.DAY_OF_MONTH),
            bulan = c.get(Calendar.MONTH),
            tahun = c.get(Calendar.YEAR);
        
        String txt = getNamaHari(c.get(Calendar.DAY_OF_WEEK)) + ", " +
                tanggal + " " + getNamaBulan(bulan) + " "  + tahun;
        
        this.lbl_tgl.setText(txt);
    }
     private Calendar kalender = Calendar.getInstance();
    
    public String getNamaHari(int dayOfWeek){
        switch(kalender.get(Calendar.DAY_OF_WEEK)){
            case Calendar.SUNDAY: return "Minggu";
            case Calendar.MONDAY: return "Senin";
            case Calendar.TUESDAY: return "Selasa";
            case Calendar.WEDNESDAY: return "Rabu";
            case Calendar.THURSDAY: return "Kamis";
            case Calendar.FRIDAY: return "Jumat";
            case Calendar.SATURDAY: return "Sabtu";
            default: return "null";
        }
    }
    
    public String getNamaBulan(int bulan){
        switch(bulan){
            case Calendar.JANUARY: return "Januari";
            case Calendar.FEBRUARY: return "Februari";
            case Calendar.MARCH: return "Maret";
            case Calendar.APRIL: return "April";
            case Calendar.MAY: return "Mei";
            case Calendar.JUNE: return "Juni";
            case Calendar.JULY: return "Juli";
            case Calendar.AUGUST: return "Agustus";
            case Calendar.SEPTEMBER: return "September";
            case Calendar.OCTOBER: return "Oktober";
            case Calendar.NOVEMBER: return "November";
            case Calendar.DECEMBER: return "Desember";
            default: return "null";
        }
    }
     private void showData(String idSupplier){
        try{
            String query = "SELECT * FROM supplier WHERE id_supplier = '"+id_supplier+"'";
            Connection conn = (Connection)CONNECTION.Conec.GetConnection();
            Statement stat = conn.createStatement();
            ResultSet r = stat.executeQuery(query);
            
            if(r.next()){
                this.id_supplier.setText(r.getString("id_supplier"));
                this.txt_nama.setText(r.getString("nama"));
                this.txt_telp.setText(r.getString("no_telp"));
                this.txt_alamat.setText(r.getString("alamat"));
           }
            
        }catch(SQLException ex){
            ex.printStackTrace();
            System.out.println(ex.getMessage());
        } 
    }
     public void tabelSupplier () {
        DefaultTableModel tbl = new DefaultTableModel();
        tbl.addColumn("id_supplier");
        tbl.addColumn("nama_supplier");
        tbl.addColumn("no_telp");
        tbl.addColumn("alamat");
        tabel_supplier.setModel(tbl);
        try {
           Connection conn = (Connection) CONNECTION.Conec.GetConnection();
           Statement stat = conn.createStatement();
            ResultSet res = stat.executeQuery("select * from supplier");
            while (res.next()) {
                tbl.addRow(new Object[]{
                    res.getString("id_supplier"),
                    res.getString("nama_supplier"),
                    res.getString("no_telp"),
                    res.getString("alamat")
                });
                tabel_supplier.setModel(tbl);
                HeaderColumn();
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "salah" + e);
        }
    }
      public void HeaderColumn() {
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();

        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
//        tabel_supplier.getColumnModel().getColumn(3).setCellRenderer(centerRenderer);
        tabel_supplier.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);

        ((DefaultTableCellRenderer) tabel_supplier.getTableHeader().getDefaultRenderer()).setHorizontalAlignment(JLabel.CENTER);

        JTableHeader thead = tabel_supplier.getTableHeader();
        thead.setForeground(Color.BLACK);
        thead.setFont(new Font("Verdana", Font.BOLD, 12));

        TableColumn column;
        tabel_supplier.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        column = tabel_supplier.getColumnModel().getColumn(0);
        column.setPreferredWidth(100);
        tabel_supplier.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        column = tabel_supplier.getColumnModel().getColumn(1);
        column.setPreferredWidth(170);
        tabel_supplier.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        column = tabel_supplier.getColumnModel().getColumn(2);
        column.setPreferredWidth(143);
        tabel_supplier.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        column = tabel_supplier.getColumnModel().getColumn(3);
        column.setPreferredWidth(161);
    }
      public void id_supplier() {
        try {
           String sql = "SELECT id_supplier FROM supplier order by id_supplier desc";
            Connection conn = (Connection) CONNECTION.Conec.GetConnection();
            Statement stm = conn.createStatement();
            ResultSet rs = stm.executeQuery(sql);

            if (rs.next()) {
                String idS = rs.getString("id_supplier").substring(2);
                String AN = "" + (Integer.parseInt(idS) + 1);
                String Nol = "";
                if (AN.length() == 1) {
                    Nol = "0";
//                } else if (AN.length() == 2) {
//                    Nol = "0";
                } else if (AN.length() == 3) {
                    Nol = "";

                }

                id_supplier.setText("SP" + Nol + AN);
            } else {
                id_supplier.setText("SP01");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "ERROR " + e.getMessage());
        }
    }
       private void filterHuruf(KeyEvent a){
        if(Character.isAlphabetic(a.getKeyChar())){
            a.consume();
        }
    }
    
    private void filterKarakter(KeyEvent a){
        if(!Character.isLetterOrDigit(a.getKeyChar())){
            a.consume();
        }
    }
    
    public void decimalOnly(KeyEvent evt){
        this.filterHuruf(evt);
        this.filterKarakter(evt);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        dasboard = new javax.swing.JButton();
        produk = new javax.swing.JButton();
        report = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabel_supplier = new javax.swing.JTable();
        txt_nama = new javax.swing.JTextField();
        txt_telp = new javax.swing.JTextField();
        txt_alamat = new javax.swing.JTextField();
        lbl_tgl = new javax.swing.JLabel();
        simpan = new javax.swing.JButton();
        hapus = new javax.swing.JButton();
        edit = new javax.swing.JButton();
        clean = new javax.swing.JButton();
        id_supplier = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        dasboard.setBackground(new java.awt.Color(0,0,0,1)
        );
        dasboard.setBorder(null);
        dasboard.setContentAreaFilled(false);
        dasboard.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        dasboard.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dasboardActionPerformed(evt);
            }
        });
        getContentPane().add(dasboard, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 168, 140, 40));

        produk.setBackground(new java.awt.Color(0,0,0,1)
        );
        produk.setBorder(null);
        produk.setContentAreaFilled(false);
        produk.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        produk.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                produkActionPerformed(evt);
            }
        });
        getContentPane().add(produk, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 218, 140, 30));

        report.setBackground(new java.awt.Color(0,0,0,1)
        );
        report.setBorder(null);
        report.setContentAreaFilled(false);
        report.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        report.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                reportActionPerformed(evt);
            }
        });
        getContentPane().add(report, new org.netbeans.lib.awtextra.AbsoluteConstraints(-10, 298, 160, 40));

        jButton4.setBackground(new java.awt.Color(0,0,0,1)
        );
        jButton4.setBorder(null);
        jButton4.setContentAreaFilled(false);
        jButton4.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 710, 120, 40));

        tabel_supplier.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "id_supplier", "nama_supplier", "no_telp", "alamat"
            }
        ));
        jScrollPane1.setViewportView(tabel_supplier);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(166, 100, 580, 250));

        txt_nama.setBackground(new java.awt.Color(0,0,0,1)
        );
        txt_nama.setBorder(null);
        getContentPane().add(txt_nama, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 568, 230, 30));

        txt_telp.setBackground(new java.awt.Color(0,0,0,1)
        );
        txt_telp.setBorder(null);
        getContentPane().add(txt_telp, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 610, 230, 30));

        txt_alamat.setBackground(new java.awt.Color(0,0,0,1)
        );
        txt_alamat.setBorder(null);
        getContentPane().add(txt_alamat, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 650, 230, 30));

        lbl_tgl.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 14)); // NOI18N
        getContentPane().add(lbl_tgl, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 50, 240, 30));

        simpan.setBackground(new java.awt.Color(0,0,0,1)
        );
        simpan.setBorder(null);
        simpan.setContentAreaFilled(false);
        simpan.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        simpan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                simpanActionPerformed(evt);
            }
        });
        getContentPane().add(simpan, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 520, 150, 60));

        hapus.setBackground(new java.awt.Color(0,0,0,1)
        );
        hapus.setBorder(null);
        hapus.setContentAreaFilled(false);
        hapus.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        hapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hapusActionPerformed(evt);
            }
        });
        getContentPane().add(hapus, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 620, 150, 60));

        edit.setBackground(new java.awt.Color(0,0,0,1)
        );
        edit.setBorder(null);
        edit.setContentAreaFilled(false);
        edit.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        edit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editActionPerformed(evt);
            }
        });
        getContentPane().add(edit, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 520, 150, 70));

        clean.setBackground(new java.awt.Color(0,0,0,1)
        );
        clean.setBorder(null);
        clean.setContentAreaFilled(false);
        clean.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        clean.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cleanActionPerformed(evt);
            }
        });
        getContentPane().add(clean, new org.netbeans.lib.awtextra.AbsoluteConstraints(863, 618, 170, 70));

        id_supplier.setBackground(new java.awt.Color(0,0,0,1)
        );
        id_supplier.setBorder(null);
        getContentPane().add(id_supplier, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 518, 230, 40));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/TAMPILAN/SUPPLIERnew_1.png"))); // NOI18N
        jLabel1.setText("jLabel1");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1080, -1));

        setSize(new java.awt.Dimension(1094, 804));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void dasboardActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dasboardActionPerformed
        // TODO add your handling code here:
        DASBOARD DASBOARD =new DASBOARD();
        DASBOARD.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_dasboardActionPerformed

    private void produkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_produkActionPerformed
        // TODO add your handling code here:
        PRODUK PRODUK =new PRODUK();
        PRODUK.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_produkActionPerformed

    private void reportActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_reportActionPerformed
        // TODO add your handling code here:
        REPORT REPORT =new REPORT();
        REPORT.setVisible(true);
        this.dispose();
        
    }//GEN-LAST:event_reportActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
        Login Login =new Login();
        Login.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton4ActionPerformed

    private void editActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editActionPerformed
        // TODO add your handling code here:
         if(this.txt_telp.getText().length() > 13){
        JOptionPane.showMessageDialog(this, "No telp tidak boleh lebih dari 13");
        return;
        }
        try {
            String id_supplier = this.id_supplier.getText(),
            nama_supplier = this.txt_nama.getText(),
            no_telp = this.txt_telp.getText(),
            alamat = this.txt_alamat.getText(),
            sql = String.format("UPDATE supplier SET nama_supplier= '%s', no_telp= '%s', alamat = '%s' WHERE id_supplier = '%s'", nama_supplier, no_telp, alamat,id_supplier);

            System.out.println("ID Supplier : " + id_supplier);

            Connection conn = (Connection) CONNECTION.Conec.GetConnection();;
            Statement stat = conn.createStatement();
            stat.executeUpdate(sql);
            JOptionPane.showMessageDialog(this, "Data berhasil diupdate!");
            this.showData(id_supplier);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage());
        }
        this.id_supplier.setText("");
        this.txt_nama.setText("");
        this.txt_telp.setText("");
        this.txt_alamat.setText("");
        this.tabelSupplier();
        id_supplier();
    }//GEN-LAST:event_editActionPerformed

    private void simpanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_simpanActionPerformed
        // TODO add your handling code here:
        String id_supplier = this.id_supplier.getText(),
        nama_supplier = this.txt_nama.getText(),
        no_telp = this.txt_telp.getText(),
        alamat = this.txt_alamat.getText();
        if(this.txt_telp.getText().length() > 13){
        JOptionPane.showMessageDialog(this, "No telp tidak boleh lebih dari 13");
        return;
        }
        try {
            String sql = "INSERT INTO supplier VALUES (?, ?, ?, ?)";
            Connection conn = (Connection) CONNECTION.Conec.GetConnection();
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, id_supplier);
            pst.setString(2, nama_supplier);
            pst.setString(3, no_telp);
            pst.setString(4, alamat);
            // eksekusi query
            pst.executeUpdate();
            JOptionPane.showMessageDialog(this, "Data berhasil ditambahkan!");
            conn.close();
        }catch(SQLException ex){
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error : " + ex.getMessage());
        }
        this.id_supplier.setText("");
        this.txt_nama.setText("");
        this.txt_telp.setText("");
        this.txt_alamat.setText("");
        this.tabelSupplier();
        id_supplier();
    }//GEN-LAST:event_simpanActionPerformed

    private void hapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hapusActionPerformed
        // TODO add your handling code here:
        int status;
        status = JOptionPane.showConfirmDialog(this, "Apakah anda yakin ingin menghapus data?", "Confirm", JOptionPane.YES_OPTION, JOptionPane.QUESTION_MESSAGE);
        switch(status){
            case JOptionPane.YES_OPTION : 
                try{
            String id_supplier = this.id_supplier.getText(),
            sql = "DELETE FROM supplier WHERE id_supplier = '" + id_supplier + "'";

            Connection conn = (Connection) CONNECTION.Conec.GetConnection();
            Statement stat = conn.createStatement();
            // mengecek apakah data pembeli berhasil terhapus atau tidak
            if(stat.executeUpdate(sql) > 0){
                JOptionPane.showMessageDialog(this, "Data berhasil dihapus!");
                // mengupdate tabel
                //                this.showData(idK);
                this.tabelSupplier();
            }else{
                JOptionPane.showMessageDialog(this, "Data gagal dihapus!");
            }
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(this, ex.getMessage());
        }
        this.id_supplier.setText("");
        this.txt_nama.setText("");
        this.txt_telp.setText("");
        this.txt_alamat.setText("");
        this.tabelSupplier();
        id_supplier();
                break;
        }
    }//GEN-LAST:event_hapusActionPerformed

    private void cleanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cleanActionPerformed
        // TODO add your handling code here:
        this.txt_nama.setText("");
        this.txt_telp.setText("");
        this.txt_alamat.setText("");
        id_supplier();
        tabelSupplier();
    }//GEN-LAST:event_cleanActionPerformed
 
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(SUPPLIER.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(SUPPLIER.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(SUPPLIER.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(SUPPLIER.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SUPPLIER().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton clean;
    private javax.swing.JButton dasboard;
    private javax.swing.JButton edit;
    private javax.swing.JButton hapus;
    private javax.swing.JTextField id_supplier;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lbl_tgl;
    private javax.swing.JButton produk;
    private javax.swing.JButton report;
    private javax.swing.JButton simpan;
    private javax.swing.JTable tabel_supplier;
    private javax.swing.JTextField txt_alamat;
    private javax.swing.JTextField txt_nama;
    private javax.swing.JTextField txt_telp;
    // End of variables declaration//GEN-END:variables
}
